package cz.martykan.forecastie.utils.formatters;

public enum WeatherFormatterType { NOTIFICATION_DEFAULT, NOTIFICATION_SIMPLE }
